import React from 'react';
import './Home.css';

const HomePage = () => {
  return (
    <div className='home_page'>Welcome to OneNaira Application!</div>
  )
}

export default HomePage